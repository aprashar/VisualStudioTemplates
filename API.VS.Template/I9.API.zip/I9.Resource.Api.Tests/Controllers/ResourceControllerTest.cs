﻿using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace I9.$resource$.Tests.Controllers
{
    [TestClass]
    public class $resource$ControllerTest
    {
        [TestMethod]
        public void Index()
        {
           
        }
    }
}
