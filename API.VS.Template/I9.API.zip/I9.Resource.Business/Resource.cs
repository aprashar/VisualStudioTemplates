﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using I9.$resource$.Interfaces;

namespace I9.$resource$.Business
{
    public class $resource$ : IDomainEntity
    {

    }
}
