﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace I9.$resource$.Data.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
