﻿using System.Web;
using System.Web.Http.Filters;

namespace I9.Resource.Api
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(HttpFilterCollection filters)
        {
            //filters.Add(new HandleErrorAttribute());
        }
    }
}
